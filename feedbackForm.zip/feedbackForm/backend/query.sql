CREATE TABLE feedbackInfo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    stars INTEGER,
    message TEXT
);
