CREATE TABLE jury (
    jury_id INTEGER PRIMARY KEY AUTOINCREMENT,
    jury_name TEXT,
    dt DATETIME
);

CREATE TABLE team1 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team2 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team3 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team4 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team5 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team6 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team7 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team8 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team9 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team10 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team11 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team12 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team13 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team14 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

CREATE TABLE team15 (
    feedback_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rev_id INTEGER,
    pres INTEGER,
    wor INTEGER,
    x INTEGER,
    msg TEXT,
    FOREIGN KEY(rev_id) REFERENCES jury(jury_id)
);

INSERT INTO jury (jury_name, dt) VALUES('Ram', CURRENT_TIMESTAMP);
INSERT INTO jury (jury_name, dt) VALUES('Shaym', CURRENT_TIMESTAMP);
INSERT INTO jury (jury_name, dt) VALUES('Bham', CURRENT_TIMESTAMP);

INSERT INTO team1 (rev_id, pres, wor, x, msg) VALUES(1, 5, 6, 3, "ASDHAS");
INSERT INTO team2 (rev_id, pres, wor, x, msg) VALUES(2, 5, 6, 3, "ASDHAS");
INSERT INTO team3 (rev_id, pres, wor, x, msg) VALUES(3, 5, 6, 3, "ASDHAS");
INSERT INTO team1 (rev_id, pres, wor, x, msg) VALUES(2, 5, 6, 3, "ASDHAS");
INSERT INTO team1 (rev_id, pres, wor, x, msg) VALUES(3, 5, 6, 3, "ASDHAS");