import sqlite3
from datetime import datetime
import json
from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_cors import CORS

app = Flask(__name__)
# set a secret key for session management
app.secret_key = "!/!kl41234lkasdfsdjfa"
CORS(app)

# Create a hardcoded username and password
username = 'admin'
password = 'password'

conn = sqlite3.connect('feedback.db')
cursor = conn.cursor()
cursor.execute('''
                    CREATE TABLE IF NOT EXISTS review (
                      rev_id INTEGER PRIMARY KEY AUTOINCREMENT,
                      reviewer_name VARCHAR(50),
                      review_time DATETIME
                    );
''')
for x in range(1, 16):
    cursor.execute('''
                    CREATE TABLE IF NOT EXISTS team'''+str(x)+''' (
                      team1_id INTEGER PRIMARY KEY AUTOINCREMENT,
                      rev_id INT,
                      field1 INT,
                      field2 INT,
                      field3 INT,
                      field4 INT,
                      msg VARCHAR(255),
                      FOREIGN KEY (rev_id) REFERENCES review(rev_id)
                    );
    ''')
cursor.execute(
    '''INSERT INTO review(reviewer_name, review_time) VALUES('Ram', CURRENT_TIMESTAMP);''')
cursor.execute(
    '''INSERT INTO review(reviewer_name, review_time) VALUES('Shaym', CURRENT_TIMESTAMP);''')
cursor.execute(
    '''INSERT INTO review(reviewer_name, review_time) VALUES('Bham', CURRENT_TIMESTAMP);''')
cursor.execute(
    '''INSERT INTO team1(rev_id, field1, field2, field3, field4, msg) VALUES(1, 5, 6, 3, 1, "ASDHAS");''')
cursor.execute(
    '''INSERT INTO team2(rev_id, field1, field2, field3, field4, msg) VALUES(2, 5, 6, 3, 1, "ASDHAS");''')
cursor.execute(
    '''INSERT INTO team3(rev_id, field1, field2, field3, field4, msg) VALUES(3, 5, 6, 3, 1, "ASDHAS");''')
cursor.execute(
    '''INSERT INTO team1(rev_id, field1, field2, field3, field4, msg) VALUES(2, 5, 6, 3, 1, "ASDHAS");''')
cursor.execute('''INSERT INTO team1(rev_id, field1, field2, field3, field4, msg) VALUES(3, 5, 6, 3, 1, "ASDHAS");
''')
cursor.close()
conn.commit()
conn.close()


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != username or request.form['password'] != password:
            error = 'Invalid Credentials. Please try again.'
        else:
            session['logged_in'] = True
            flash('You were logged in')
            return redirect(url_for('dashboard'))
    return render_template('login.html', error=error)


@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You were logged out')
    return redirect(url_for('login'))


@app.route('/')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    conn = sqlite3.connect('feedback.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM feedbackInfo')
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('dashboard.html', rows=rows)


@app.route('/submit', methods=['POST'])
def submit():
    form_data = request.form
    for key, value in form_data.items():
        print(key + ': ' + value)
    return render_template('success.html')

    # conn = sqlite3.connect('feedback.db')
    # cursor = conn.cursor()
    # # data = request.json
    # data = {"name": "bhuvansa"}
    # now = datetime.now()
    # date = now.date()
    # print(date)
    # time = now.time()
    # print(time)
    # cursor.execute('''INSERT INTO review(reviewer_name) VALUES(?); ''',
    #                ("bhuvansa"))
    # cursor.execute(''' SELECT MAX(rev_id) FROM review; ''')
    # rev_id = cursor.fetchone()
    # print(rev_id)
    # for x in range(1, 16):
    #     tb_name = "team" + str(x)
    #     cursor.execute(
    #         ''' INSERT INTO ?
    #         (rev_id, field1, field2, field3, field3, field4, msg)
    #         VALUES(?, ?, ?, ?, ?);''', (
    #             tb_name, (rev_id, 1, 2, 3, 4)))
    # conn.commit()
    # cursor.close()
    # conn.close()
    # return json.dumps({'success': True}), 200, {'ContentType': 'application/json'}


if __name__ == '__main__':
    print("hi")
    app.run()
